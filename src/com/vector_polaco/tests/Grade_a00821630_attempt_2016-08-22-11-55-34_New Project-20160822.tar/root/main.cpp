#include <iostream>

using namespace std;


// The program is to calculate the Character that corresponds to your Grade
// Parameters: A >=90   B>=80 and <90   C>=70 and <80   D>=60 and <70
//  E for anyother
double Grade(string sMessage)
{
    double dGrade;
    cout << sMessage <<  endl;
    cin >> dGrade;
    return dGrade;
}

// To see the parameters


char CalculateGrade(double dGrade)
{
    char cGrade;
    if (dGrade >= 90)
    {
        cGrade = 'A';
    }
    else if (dGrade >= 80 && dGrade > 90)
    {
        cGrade = 'B';
    }
    else if (dGrade >= 70 && dGrade > 80)
    {
        cGrade = 'C' ;
    }
    else if (dGrade >= 60 && dGrade > 70)
    {
        cGrade ='D';
    }
    else 
    {
        cGrade = 'E';
    }
    return cGrade;
}

// To Display the Grade and Character
void Display(double dGrade, char cGrade)
{
    cout << "Your Character is: " << cGrade << " And Your Grade is: " << dGrade << endl;
}

int main()
{
    // Declaring the variables to store the Grade and character
   double dGrade;
   char cGrade;
   dGrade = Grade("Enter Grade");
   cGrade = CalculateGrade(dGrade);

    // To Display the variables
   Display(dGrade, cGrade);
   return 0;
}

