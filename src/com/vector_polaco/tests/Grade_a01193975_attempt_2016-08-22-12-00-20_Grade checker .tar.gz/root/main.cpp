#include <iostream>

using namespace std;


//Grade checker 



double GetGrade(string sMessage) //gets the grade
{
    double dGrade;
    cout << sMessage << endl;
    cin >> dGrade;

return dGrade;
}

char caclulate(double dGrade) // checks the letter 
{
    char cGrade;
    if (dGrade>= 90)
    {
    cGrade= 'A';
    }
    else if(dGrade >= 80)
    {
    cGrade= 'B';
    }
    else if (dGrade>= 70)
    {
    cGrade= 'C';
    }
    else if(dGrade >= 60)
    {
    cGrade= 'D';
    }
    else 
    {
    cGrade= 'E';
    }
    
    
    return cGrade;
    
}


void display(char cGrade) // displays the grade 
{
cout<< "the grade is" << cGrade;
} 

int main()  // gets the message
{
    double dGrade = GetGrade("Enter Grade");
   
   
   
   return 0;
}

